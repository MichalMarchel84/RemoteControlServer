const robotId = 0;
const password = "";